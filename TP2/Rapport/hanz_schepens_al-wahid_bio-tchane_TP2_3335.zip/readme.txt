Auteurs:
Hanz Schepens 20189679
Al-Wahid Bio-Tchane 20137307

GitHub Repo: https://github.com/Wickkawizz/IFT-3335_TPs
